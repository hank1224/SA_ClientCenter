from django.apps import AppConfig


class LineloginappConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "LineLoginApp"
